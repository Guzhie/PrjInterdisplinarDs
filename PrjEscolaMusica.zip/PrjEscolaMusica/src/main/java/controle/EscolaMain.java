/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import javax.swing.JFrame;

import javax.swing.*;
import java.awt.*;

public class EscolaMain {
    public static void main(String[] args) {
        EscolaMenu app = new EscolaMenu(); 
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
}
